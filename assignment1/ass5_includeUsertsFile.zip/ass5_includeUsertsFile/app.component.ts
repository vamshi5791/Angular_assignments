import { Component } from '@angular/core';
import{User} from './user'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular';
  users = [
    new User('vamshi', 20),
    new User('kiran', 22),
    new User('megana', 30)
  ];
}
