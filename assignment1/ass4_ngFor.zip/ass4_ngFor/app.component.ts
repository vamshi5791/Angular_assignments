import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular';
   users=[{name:'vamshi',age:24},{name:'rajashekar',age:27},{name:'bhuvan',age:33}]
}
